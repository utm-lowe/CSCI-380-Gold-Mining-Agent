# Gold Miner Agent
Your task in this assignment is to write an agent for a gold mining robot. This assignnment is intended to be done using github codespaces, and further instructions can by found in GoldMine.ipynb. That's the only file you really need to edit. 

Have fun!
